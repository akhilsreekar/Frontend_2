package com.apps.akhilsreekar.frontend;

/**
 * Created by AKHIL on 27-09-2016.
 */
public class Information {
    public int imageId;
    public String title;
}
