    package com.apps.akhilsreekar.frontend;

import java.util.ArrayList;

/**
 * Created by AKHIL on 27-09-2016.
 */
public class Data {

    public static ArrayList<Information> getData() {
        ArrayList<Information> data = new ArrayList<>();

        int[] images = {
                R.drawable.scene1,
                R.drawable.scene2,
                R.drawable.scene3,
                R.drawable.scene4,
                R.drawable.scene5
        };

        String[] Categories = {
                "scene1", "scene2", "scene3", "scene4", "scene5"
        };

        for (int i = 0; i < images.length; i++) {
            Information current = new Information();
            current.title = Categories[i];
            current.imageId = images[i];

            data.add(current);
        }

        return data;
    }
}
